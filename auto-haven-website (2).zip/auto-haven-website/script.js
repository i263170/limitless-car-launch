console.log("Auto Haven Luxury Engine Initialized");

// 1. Interactive Reservation Alert
function reserveVehicle(carName) {
    console.log("Reservation triggered for:", carName);
    window.alert("VIP Concierge: Your reservation inquiry for the " + carName + " has been prioritized. An advisor will contact you within 15 minutes.");
}

// 2. Live Financing / EMI Calculator
function calculateInstallment() {
    const price = parseFloat(document.getElementById("carSelect").value);
    const downPercent = parseFloat(document.getElementById("downPayment").value);
    const months = parseInt(document.getElementById("tenure").value);

    if (isNaN(downPercent) || downPercent < 0 || downPercent >= 100) {
        window.alert("Please enter a valid down payment percentage between 0 and 99.");
        return;
    }

    const downAmount = price * (downPercent / 100);
    const loanAmount = price - downAmount;
    const annualRate = 0.14; // 14% markup
    const monthlyRate = annualRate / 12;

    const emi = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);
    const formattedEMI = Math.round(emi).toLocaleString();

    console.log("Calculated Monthly EMI: PKR", formattedEMI);
    document.getElementById("emiOutput").innerText = "Estimated Monthly Payment: PKR " + formattedEMI + " / month";
}

// 3. Gallery Category Filter
function filterVehicles(category, btnElement) {
    console.log("Filtering showroom by:", category);

    const buttons = document.querySelectorAll(".filter-btn");
    buttons.forEach(btn => btn.classList.remove("active"));
    btnElement.classList.add("active");

    const cards = document.querySelectorAll(".vehicle-card");
    cards.forEach(card => {
        if (category === "all" || card.getAttribute("data-category") === category) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }
    });
}

// 4. Contact Form Handler with LocalStorage Persistence
function submitInquiry(event) {
    event.preventDefault();

    const name = document.getElementById("fullName").value.trim();
    const email = document.getElementById("emailAddress").value.trim();
    const model = document.getElementById("preferredModel").value;

    if (!name || !email) {
        window.alert("Please complete all required fields.");
        return;
    }

    const record = { name, email, model, timestamp: new Date().toISOString() };
    localStorage.setItem("autoHaven_booking", JSON.stringify(record));
    console.log("Booking stored:", record);

    window.alert("Confirmed, " + name + "! Your private test drive for the " + model + " is scheduled.");
    document.getElementById("vipForm").reset();
}
