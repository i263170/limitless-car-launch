# Auto Haven Website

- **Name / Roll Number / Section**: ikrash, i263170, se d
- **Theme**: Auto Haven - A luxury automotive showcase and dealership portal.
- **Pages**: 
  - Home (index.html)
  - Showroom (gallery.html)
  - Concierge (contact.html)
- **AI Tools Used**: Gemini
- **Live Website**: https://[your-username].github.io/auto-haven-website/
